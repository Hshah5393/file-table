import { combineReducers } from "redux";
import fileTableReducer from "../reducers/file-table-reducer";
const reducer = combineReducers({
  fileTable: fileTableReducer
});

export default reducer;
