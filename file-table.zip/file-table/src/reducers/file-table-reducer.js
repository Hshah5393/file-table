const defaultState = {
  selectedFiles: [],
  checkBoxStatus: "empty",
  filesDetails: []
};
export default function (state = defaultState, action) {
  switch (action.type) {
    case "fetchDataError":
      return Object.assign({}, state, {
        hasError: true,
        displayError: action.payload
      });
    case "fetchDataSuccess":
      let result = action.payload.data.map((x) => {
        x.selected = "";
        return x;
      }
      )
      return Object.assign({}, state, {
        hasError: false,
        filesDetails: result
      });
    case "updateSelectedFiles":
      return Object.assign({}, state, {
        filesDetails: action.payload,
        selectedFiles: action.payload.filter((x) => x.selected)
      });
    case ('setCheckBoxStatus'):
      return Object.assign({}, state, {
        checkBoxStatus : action.payload
      });
    default:
      return state;
  }
}
