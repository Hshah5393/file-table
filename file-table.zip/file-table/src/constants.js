export const CheckBoxStatus = {
    Checked: 'checked',
    Indeterminate: 'indeterminate',
    Empty: 'empty',
  }