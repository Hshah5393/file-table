import { Fragment } from "react";

const downloadable = (files, status) => {
  let result = files.filter((file) => {
    return file.status.toLowerCase() === status;
  });
  return result;
};
const AlertFilesDownload = (props) => {
  const { cancel, selectedFiles } = props;
  return (
    <div
      className="alert alert-warning alert-dismissible fade show"
      role="alert"
    >
      <button
        type="button"
        className="btn-close"
        aria-label="Close"
        onClick={(e) => cancel()}
      ></button>
      <div>
        {downloadable(selectedFiles) ? (
          <Fragment>
            <strong>Files Available for Download</strong>
            <ol>
              {downloadable(selectedFiles, "available").map((file) => {
                return (
                  <li>
                    Device: {file.device} Path: {file.path}
                  </li>
                );
              })}
            </ol>
          </Fragment>
        ) : null}

        {downloadable(selectedFiles) ? (
          <Fragment>
            <strong>Currently not available for download</strong>
            <ol>
              {downloadable(selectedFiles, "scheduled").map((file) => {
                return (
                  <li>
                    Device: {file.device} Path: {file.path}
                  </li>
                );
              })}
            </ol>
          </Fragment>
        ) : null}
      </div>
    </div>
  );
};

export default AlertFilesDownload;
