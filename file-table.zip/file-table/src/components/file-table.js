const FileTable = (props) => {
  const { fileDetails, onChangeSingleFileCheck } = props;
  return (
    <table className="table table-hover border">
      <thead>
        <tr>
          <th className="col-sm-1"></th>
          <th className="col-sm-2 text-start">Name</th>
          <th className="col-sm-2 text-start">Device</th>
          <th className="col-sm-7 text-start">Path</th>
          <th className="col-sm-1 text-start">Status</th>
        </tr>
      </thead>
      <tbody>
        {fileDetails.map((fileDetail, x) => (
          <tr
            key={`file_${x}`}
            className={`${fileDetail.selected ? "selected" : ""} table-rows`}
          >
            <td>
              <input
                type="checkbox"
                id={fileDetail.name}
                className="form-check-input"
                checked={fileDetail.selected}
                onChange={(e) => {
                  onChangeSingleFileCheck(e, fileDetail);
                }}
              />
            </td>
            <td className="text-start">{fileDetail.name}</td>
            <td className="text-start">{fileDetail.device}</td>
            <td className="text-start">
              {fileDetail.path}
              {fileDetail.status.toLowerCase() === "available" ? (
                <span className="dot text-end"></span>
              ) : null}
            </td>
            <td className="text-start">{fileDetail.status}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default FileTable;
