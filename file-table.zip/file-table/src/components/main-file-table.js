import { Component } from "react";
import { bindActionCreators } from "redux";
import FileTable from "./file-table";
import FileTableHeader from "./file-table-header";
import { fetchFiles, handleActions } from "../actions/file-table-action";
import { connect } from "react-redux";
import AlertFilesDownload from "./alert-files-download";
import { CheckBoxStatus } from "../constants";

class MainFileTable extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showAlert: false
    };
    this.closeAlert = this.closeAlert.bind(this);
    this.showAlert = this.showAlert.bind(this);
    this.onChangeSingleFileCheck = this.onChangeSingleFileCheck.bind(this);
    this.onMasterCheck = this.onMasterCheck.bind(this);
  }
  componentDidMount() {
    this.props.fetchFiles();

  }
  onMasterCheck(e) {
    this.closeAlert();
    let tempFiles = this.props.filesDetails;
    tempFiles.map((file) => (file.selected = e.target.checked));
    this.props.handleActions("updateSelectedFiles", tempFiles);
  }

  evaluateCheckBoxStatus(files) {
    let arr =  files.filter((x) => x.selected)

    if(arr.length > 0) {
      if(arr.length < this.props.filesDetails.length) {
        this.props.handleActions("setCheckBoxStatus", CheckBoxStatus.Indeterminate)
      } else if (arr.length  === this.props.filesDetails.length) {
        this.props.handleActions("setCheckBoxStatus", CheckBoxStatus.Checked)
      } 
    } else {
      this.props.handleActions("setCheckBoxStatus", CheckBoxStatus.Empty)
    }
  }

  onChangeSingleFileCheck(e, file) {
    this.closeAlert();
    let tempFiles = this.props.filesDetails;
    tempFiles.map((x) => {
      if (x.name === file.name) {
        file.selected = e.target.checked;
      }
      return x;
    });
    this.props.handleActions("updateSelectedFiles", tempFiles);
    this.evaluateCheckBoxStatus(tempFiles);
  }

  showAlert() {
    this.setState({ showAlert: true });
  }

  closeAlert() {
    this.setState({ showAlert: false });
  }
  render() {
    return (
      <div className="container">
        {this.state.showAlert ? 
          <AlertFilesDownload
            cancel={() => {this.closeAlert()}}
            selectedFiles={this.props.selectedFiles}
          /> 
        : null}
        <div className="row" id="file-table-header">
          <FileTableHeader
            count={this.props.selectedFiles?.length}
            onChangeMasterCheckbox={(e) => this.onMasterCheck(e)}
            downloadAll={(e) => this.showAlert()}
            disablebtn = {this.props.selectedFiles?.length > 0 ? "" : "disabled"}
            checkBoxStatus = {this.props.checkBoxStatus}
          />
        </div>
        <div className="row">
          <FileTable
            fileDetails={this.props.filesDetails}
            onChangeSingleFileCheck={(e, file) =>
              this.onChangeSingleFileCheck(e, file)
            }
          />
        </div>
      </div>
    );
  }
}

function mapDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      fetchFiles,
      handleActions
    },
    dispatch
  );
}

function mapStateToProps(state) {
  return {
    filesDetails: state.fileTable.filesDetails,
    selectedFiles: state.fileTable.selectedFiles,
    checkBoxStatus: state.fileTable.checkBoxStatus
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(MainFileTable);
