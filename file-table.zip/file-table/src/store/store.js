import { createStore, applyMiddleware, compose } from "redux";
import thunk from "redux-thunk";
import reducer from "../reducers/index";

const initialState = {};

const composedEnhancer = compose(applyMiddleware(thunk))(createStore);
const store = composedEnhancer(reducer, initialState);

export default store;
