import { mockAPI } from "../api/mockAPI";
export function fetchFiles() {
  return function (dispatch) {
    const request = {
      method: "get"
    };
    mockAPI(request)
      .then((response) => {
        dispatch(handleActions("fetchDataSuccess", response.data));
      })
      .catch((error) => {
        dispatch(handleActions("fetchDataError", error));
      });
  };
}

export function handleActions(type, val = null) {
  return {
    type: type,
    payload: val
  };
}
