import MainFileTable from "./components/main-file-table";
import "./styles.css";

const App = () => {
  return (
    <div className="App">
      <MainFileTable />
    </div>
  );
};

export default App;
